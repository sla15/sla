import { nanoid } from 'nanoid';

export class PeerConnection {
  private peerConnection: RTCPeerConnection;
  private dataChannel: RTCDataChannel | null = null;
  private roomId: string;
  
  constructor(onReceiveFile: (file: Blob, filename: string) => void) {
    this.roomId = nanoid(6);
    this.peerConnection = new RTCPeerConnection({
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
      ]
    });

    this.peerConnection.ondatachannel = (event) => {
      const receiveChannel = event.channel;
      this.setupDataChannel(receiveChannel, onReceiveFile);
    };
  }

  async createRoom(): Promise<string> {
    this.dataChannel = this.peerConnection.createDataChannel('fileTransfer');
    const offer = await this.peerConnection.createOffer();
    await this.peerConnection.setLocalDescription(offer);
    return this.roomId;
  }

  async joinRoom(remoteOffer: RTCSessionDescriptionInit): Promise<RTCSessionDescriptionInit> {
    await this.peerConnection.setRemoteDescription(remoteOffer);
    const answer = await this.peerConnection.createAnswer();
    await this.peerConnection.setLocalDescription(answer);
    return answer;
  }

  private setupDataChannel(channel: RTCDataChannel, onReceiveFile: (file: Blob, filename: string) => void) {
    let receivedSize = 0;
    let fileSize = 0;
    let fileChunks: Blob[] = [];
    let filename = '';

    channel.onmessage = async (event) => {
      if (typeof event.data === 'string') {
        const metadata = JSON.parse(event.data);
        fileSize = metadata.size;
        filename = metadata.name;
        receivedSize = 0;
        fileChunks = [];
      } else {
        fileChunks.push(event.data);
        receivedSize += event.data.size;

        if (receivedSize === fileSize) {
          const file = new Blob(fileChunks);
          onReceiveFile(file, filename);
          fileChunks = [];
        }
      }
    };
  }

  async sendFile(file: File) {
    if (!this.dataChannel) return;

    const metadata = {
      name: file.name,
      size: file.size,
      type: file.type
    };

    this.dataChannel.send(JSON.stringify(metadata));

    const chunkSize = 16384;
    const fileReader = new FileReader();
    let offset = 0;

    fileReader.onload = (e) => {
      if (!e.target?.result || !this.dataChannel) return;
      this.dataChannel.send(e.target.result as ArrayBuffer);
      offset += chunkSize;

      if (offset < file.size) {
        readSlice(offset);
      }
    };

    const readSlice = (o: number) => {
      const slice = file.slice(o, o + chunkSize);
      fileReader.readAsArrayBuffer(slice);
    };

    readSlice(0);
  }
}