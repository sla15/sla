export interface FileItem {
  file: File;
  preview?: string;
  type: 'image' | 'video' | 'other';
}