import React from 'react';
import { Upload } from 'lucide-react';

interface FileUploaderProps {
  fileInputRef: React.RefObject<HTMLInputElement>;
  handleFileSelect: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export default function FileUploader({ fileInputRef, handleFileSelect }: FileUploaderProps) {
  return (
    <div 
      className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl p-8 text-center hover:border-blue-500 dark:hover:border-blue-400 transition-colors cursor-pointer"
      onClick={() => fileInputRef.current?.click()}
    >
      <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400 dark:text-gray-500" />
      <p className="text-gray-600 dark:text-gray-300 mb-2">
        Click or drag files here to upload
      </p>
      <p className="text-sm text-gray-500 dark:text-gray-400">
        Supports images, videos, and other files
      </p>
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileSelect}
        multiple
        className="hidden"
        accept="image/*,video/*,application/*"
      />
    </div>
  );
}