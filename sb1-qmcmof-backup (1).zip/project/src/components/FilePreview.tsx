import React from 'react';
import { Image, FileVideo, File, Share2, Check } from 'lucide-react';
import { FileItem } from '../types';

interface FilePreviewProps {
  files: FileItem[];
  shared: boolean;
  handleShare: () => Promise<void>;
  clearFiles: () => void;
}

export default function FilePreview({ files, shared, handleShare, clearFiles }: FilePreviewProps) {
  const getFileIcon = (type: string) => {
    switch (type) {
      case 'image':
        return <Image className="w-6 h-6" />;
      case 'video':
        return <FileVideo className="w-6 h-6" />;
      default:
        return <File className="w-6 h-6" />;
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {files.map((file, index) => (
          <div key={index} className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 flex items-center space-x-4">
            {file.preview ? (
              <img src={file.preview} alt="" className="w-16 h-16 object-cover rounded" />
            ) : (
              <div className="w-16 h-16 bg-gray-200 dark:bg-gray-700 rounded flex items-center justify-center">
                {getFileIcon(file.type)}
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">
                {file.file.name}
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {(file.file.size / 1024 / 1024).toFixed(2)} MB
              </p>
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-center space-x-4">
        <button
          onClick={handleShare}
          className={`flex items-center px-6 py-3 rounded-lg transition-colors ${
            shared
              ? 'bg-green-600 hover:bg-green-700'
              : 'bg-blue-600 hover:bg-blue-700'
          } text-white`}
        >
          {shared ? <Check className="w-5 h-5 mr-2" /> : <Share2 className="w-5 h-5 mr-2" />}
          {shared ? 'Shared!' : 'Share Files'}
        </button>
        <button
          onClick={clearFiles}
          className="px-6 py-3 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
        >
          Clear All
        </button>
      </div>
    </div>
  );
}