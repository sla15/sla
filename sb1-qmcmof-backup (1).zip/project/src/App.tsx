import React, { useState, useRef, useEffect } from 'react';
import Header from './components/Header';
import FileUploader from './components/FileUploader';
import FilePreview from './components/FilePreview';
import ConnectionModal from './components/ConnectionModal';
import { FileItem } from './types';
import { Share2, Wifi } from 'lucide-react';
import { PeerConnection } from './services/peerConnection';

function App() {
  const [files, setFiles] = useState<FileItem[]>([]);
  const [shared, setShared] = useState(false);
  const [showConnectionModal, setShowConnectionModal] = useState(false);
  const [roomId, setRoomId] = useState<string | null>(null);
  const [isDark, setIsDark] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('darkMode') === 'true' ||
        window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const peerConnectionRef = useRef<PeerConnection | null>(null);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDark);
    localStorage.setItem('darkMode', isDark.toString());
  }, [isDark]);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const roomParam = urlParams.get('room');
    if (roomParam) {
      joinRoom(roomParam);
    }
  }, []);

  const toggleDarkMode = () => {
    setIsDark(prev => !prev);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    const newFiles: FileItem[] = selectedFiles.map(file => ({
      file,
      preview: file.type.startsWith('image/') ? URL.createObjectURL(file) : undefined,
      type: file.type.startsWith('image/') ? 'image' : 
            file.type.startsWith('video/') ? 'video' : 'other'
    }));
    setFiles(prev => [...prev, ...newFiles]);
    setShared(false);
  };

  const handleReceiveFile = (file: Blob, filename: string) => {
    const newFile = new File([file], filename, { type: file.type });
    const fileItem: FileItem = {
      file: newFile,
      preview: file.type.startsWith('image/') ? URL.createObjectURL(file) : undefined,
      type: file.type.startsWith('image/') ? 'image' :
            file.type.startsWith('video/') ? 'video' : 'other'
    };
    setFiles(prev => [...prev, fileItem]);
  };

  const createRoom = async () => {
    peerConnectionRef.current = new PeerConnection(handleReceiveFile);
    const newRoomId = await peerConnectionRef.current.createRoom();
    setRoomId(newRoomId);
    setShowConnectionModal(true);
  };

  const joinRoom = async (roomId: string) => {
    // Implementation for joining room will be added
    console.log('Joining room:', roomId);
  };

  const handleShare = async () => {
    if (files.length === 0) return;

    try {
      if (peerConnectionRef.current) {
        for (const fileItem of files) {
          await peerConnectionRef.current.sendFile(fileItem.file);
        }
        setShared(true);
      } else if (navigator.share && navigator.canShare({ files: files.map(f => f.file) })) {
        await navigator.share({
          files: files.map(f => f.file),
          title: 'Share Files via SLA DIBBA',
          text: 'Files shared using SLA DIBBA'
        });
        setShared(true);
      } else {
        const downloadLink = document.createElement('a');
        files.forEach(fileItem => {
          downloadLink.href = URL.createObjectURL(fileItem.file);
          downloadLink.download = fileItem.file.name;
          downloadLink.click();
          URL.revokeObjectURL(downloadLink.href);
        });
        setShared(true);
      }
    } catch (error) {
      console.error('Error sharing files:', error);
    }
  };

  const clearFiles = () => {
    files.forEach(file => {
      if (file.preview) URL.revokeObjectURL(file.preview);
    });
    setFiles([]);
    setShared(false);
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-4 transition-colors duration-200`}>
      <div className="max-w-3xl mx-auto">
        <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-xl p-8 mb-8">
          <Header isDark={isDark} toggleDarkMode={toggleDarkMode} />

          <div className="space-y-6">
            <FileUploader 
              fileInputRef={fileInputRef}
              handleFileSelect={handleFileSelect}
            />

            {files.length > 0 && (
              <FilePreview
                files={files}
                shared={shared}
                handleShare={handleShare}
                clearFiles={clearFiles}
              />
            )}

            <div className="mt-8">
              <div className="text-center space-y-4">
                <button
                  onClick={createRoom}
                  className="inline-flex items-center justify-center gap-2 bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200 px-4 py-2 rounded-lg hover:bg-blue-200 dark:hover:bg-blue-900/50 transition-colors"
                >
                  <Wifi className="w-5 h-5" />
                  <span className="text-sm font-medium">Connect Nearby Device</span>
                </button>
                <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <p>To share files between devices:</p>
                  <p>1. Click "Connect Nearby Device" to start</p>
                  <p>2. Scan QR code or enter room code on other device</p>
                  <p>3. Upload and share files directly</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showConnectionModal && roomId && (
        <ConnectionModal
          roomId={roomId}
          onClose={() => setShowConnectionModal(false)}
        />
      )}
    </div>
  );
}

export default App;